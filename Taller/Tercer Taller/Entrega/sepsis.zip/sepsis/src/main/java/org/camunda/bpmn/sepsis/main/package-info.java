package org.camunda.bpmn.sepsis.main;

// Contiene la clase principal.
