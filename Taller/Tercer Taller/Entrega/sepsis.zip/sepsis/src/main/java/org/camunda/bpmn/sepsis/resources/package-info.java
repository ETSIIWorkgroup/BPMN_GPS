package org.camunda.bpmn.sepsis.resources;

// Contiene las clases encargadas de la ejecuci�n.
